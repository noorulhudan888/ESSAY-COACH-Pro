import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';

interface OutlineSection {
  heading: string;
  points: string[];
}

const OUTLINE_SYSTEM_PROMPT = `You are an expert academic writing coach specializing in essay structure and organization. 
Generate a comprehensive, well-organized essay outline based on the user's topic and target word count.
Structure the outline with clear sections and bullet points that the student can follow to write their essay.

Respond with ONLY valid JSON in this exact structure:
{
  "outline": [
    {
      "heading": "Introduction",
      "points": ["Hook statement", "Background information", "Thesis statement"]
    },
    {
      "heading": "Body Paragraph 1",
      "points": ["Topic sentence", "Supporting evidence", "Analysis", "Transition"]
    }
  ]
}

Make the outline comprehensive enough to guide the entire essay, with 4-6 main sections depending on the word count.
Include specific points within each section that the student should address.`;

const MOCK_OUTLINE: OutlineSection[] = [
  {
    heading: 'Introduction',
    points: [
      'Hook the reader with a compelling opening statement about the topic',
      'Provide context and background information on the subject matter',
      'Present your clear thesis statement that takes a definitive position',
      'Brief overview of the main arguments you will present',
    ],
  },
  {
    heading: 'Body Paragraph 1: First Main Argument',
    points: [
      'Topic sentence introducing your first key point',
      'Evidence or examples supporting this argument',
      'Analysis of how the evidence supports your thesis',
      'Transition sentence connecting to the next paragraph',
    ],
  },
  {
    heading: 'Body Paragraph 2: Second Main Argument',
    points: [
      'Topic sentence introducing your second key point',
      'Evidence or examples supporting this argument',
      'Analysis connecting the evidence to your thesis',
      'Consideration of counterarguments or alternative perspectives',
    ],
  },
  {
    heading: 'Body Paragraph 3: Third Main Argument',
    points: [
      'Topic sentence introducing your third key point',
      'Research findings, statistics, or expert opinions',
      'Analysis showing the significance of this evidence',
      'Transition to conclusion',
    ],
  },
  {
    heading: 'Conclusion',
    points: [
      'Restate your thesis in fresh language',
      'Summarize the main points from each body paragraph',
      'Discuss the broader implications of your arguments',
      'End with a powerful closing statement or call to action',
    ],
  },
];

export async function generateOutline(
  topic: string,
  wordCount: number,
  apiKey?: string,
  provider?: 'openai' | 'gemini'
): Promise<OutlineSection[]> {
  // If no API key provided or using mock, return mock outline
  if (!apiKey || !provider) {
    console.log('[v0] Using mock outline (no API key configured)');
    return MOCK_OUTLINE;
  }

  try {
    const userPrompt = `Create a detailed essay outline for the following topic and target word count:

Topic: ${topic}
Target Word Count: ${wordCount} words

The outline should have appropriate depth and section count based on the word count. Include specific points students should address in each section.`;

    if (provider === 'openai') {
      const { text } = await generateText({
        model: openai('gpt-4-turbo'),
        system: OUTLINE_SYSTEM_PROMPT,
        prompt: userPrompt,
        apiKey: apiKey,
      });

      const response = JSON.parse(text);
      return response.outline as OutlineSection[];
    } else if (provider === 'gemini') {
      // For Gemini, we'll use the fetch API directly
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' + apiKey, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: `${OUTLINE_SYSTEM_PROMPT}\n\n${userPrompt}`,
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          },
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('[v0] Gemini API error:', data);
        return MOCK_OUTLINE;
      }

      const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!responseText) {
        return MOCK_OUTLINE;
      }

      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        return MOCK_OUTLINE;
      }

      const parsedResponse = JSON.parse(jsonMatch[0]);
      return parsedResponse.outline as OutlineSection[];
    }

    return MOCK_OUTLINE;
  } catch (error) {
    console.error('[v0] Error generating outline:', error);
    // Fallback to mock outline on any error
    return MOCK_OUTLINE;
  }
}
