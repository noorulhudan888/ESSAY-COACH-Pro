export interface Essay {
  id: string;
  title: string;
  content: string;
  academicLevel: 'high-school' | 'undergrad' | 'postgrad';
  essayType: 'argumentative' | 'descriptive' | 'narrative';
  createdAt: string;
  feedback?: EssayFeedback;
}

export interface EssayFeedback {
  grade: string;
  score: number;
  structure: {
    introduction: string;
    thesis: string;
    bodyParagraphs: string;
    conclusion: string;
  };
  grammar: string[];
  actionableSteps: string[];
}

const STORAGE_KEY = 'essay_coach_essays';
const API_KEY_STORAGE = 'essay_coach_api_key';
const API_PROVIDER_STORAGE = 'essay_coach_api_provider';

export function getEssays(): Essay[] {
  if (typeof window === 'undefined') return [];
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('[v0] Failed to get essays from storage:', error);
    return [];
  }
}

export function saveEssay(essay: Essay): void {
  if (typeof window === 'undefined') return;
  try {
    const essays = getEssays();
    const existingIndex = essays.findIndex((e) => e.id === essay.id);
    if (existingIndex > -1) {
      essays[existingIndex] = essay;
    } else {
      essays.unshift(essay);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(essays));
  } catch (error) {
    console.error('[v0] Failed to save essay:', error);
  }
}

export function deleteEssay(id: string): void {
  if (typeof window === 'undefined') return;
  try {
    const essays = getEssays().filter((e) => e.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(essays));
  } catch (error) {
    console.error('[v0] Failed to delete essay:', error);
  }
}

export function getApiKey(): string {
  if (typeof window === 'undefined') return '';
  try {
    return localStorage.getItem(API_KEY_STORAGE) || '';
  } catch (error) {
    console.error('[v0] Failed to get API key:', error);
    return '';
  }
}

export function saveApiKey(key: string, provider: 'openai' | 'gemini'): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(API_KEY_STORAGE, key);
    localStorage.setItem(API_PROVIDER_STORAGE, provider);
  } catch (error) {
    console.error('[v0] Failed to save API key:', error);
  }
}

export function getApiProvider(): 'openai' | 'gemini' | null {
  if (typeof window === 'undefined') return null;
  try {
    return (localStorage.getItem(API_PROVIDER_STORAGE) as 'openai' | 'gemini') || null;
  } catch (error) {
    console.error('[v0] Failed to get API provider:', error);
    return null;
  }
}

export function clearApiKey(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(API_KEY_STORAGE);
    localStorage.removeItem(API_PROVIDER_STORAGE);
  } catch (error) {
    console.error('[v0] Failed to clear API key:', error);
  }
}
