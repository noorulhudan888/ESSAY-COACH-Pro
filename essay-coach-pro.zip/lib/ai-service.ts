import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { EssayFeedback } from './storage';

const SYSTEM_PROMPT = `You are Essay Coach Pro, an elite academic writing coach. Analyze the user's essay based on their specified academic level and essay type. Provide a JSON response covering:
1. Overall Grade (A-F style) and an overall score out of 100.
2. Structure & Flow: Critiques of the introduction, thesis statement, body paragraphs, and conclusion.
3. Grammar & Tone: Pinpoint 3 major grammatical or stylistic improvements.
4. Actionable Steps: Give 3 explicit exercises or changes the student should make to improve this exact essay.

Respond with ONLY valid JSON in this exact structure:
{
  "grade": "A",
  "score": 92,
  "structure": {
    "introduction": "Your introduction is strong...",
    "thesis": "Your thesis statement clearly...",
    "bodyParagraphs": "Your body paragraphs effectively...",
    "conclusion": "Your conclusion properly..."
  },
  "grammar": [
    "Issue 1: Description",
    "Issue 2: Description",
    "Issue 3: Description"
  ],
  "actionableSteps": [
    "Action 1: Description",
    "Action 2: Description",
    "Action 3: Description"
  ]
}`;

const MOCK_FEEDBACK: EssayFeedback = {
  grade: 'A-',
  score: 88,
  structure: {
    introduction: 'Your introduction effectively hooks the reader with a compelling opening statement. However, consider adding more context about why this topic matters before diving into your thesis.',
    thesis: 'Your thesis statement is clear and takes a definitive stance. It could be strengthened by previewing the key arguments you&apos;ll make in the body.',
    bodyParagraphs: 'Your body paragraphs are well-organized with clear topic sentences. Each paragraph effectively supports your thesis with relevant evidence and analysis.',
    conclusion: 'Your conclusion effectively summarizes your main points and restates your thesis. Consider ending with a broader implication or call to action.',
  },
  grammar: [
    'Sentence variety: Several sentences begin with "The" - try varying your sentence structures to maintain reader engagement.',
    'Passive voice: "It was observed that..." should be "Researchers observed..." for more direct, active prose.',
    'Word choice: "Very important" can be replaced with stronger words like "crucial," "essential," or "vital."',
  ],
  actionableSteps: [
    'Exercise 1: Outline your essay in reverse - write down the main claim of each paragraph to ensure logical flow and coherence.',
    'Exercise 2: Read your essay aloud slowly. Mark any sentences that feel awkward or unclear, then rewrite them for clarity.',
    'Exercise 3: Add at least one counter-argument in your body and then refute it. This strengthens your argumentative position significantly.',
  ],
};

export async function analyzeEssay(
  essay: string,
  academicLevel: string,
  essayType: string,
  apiKey?: string,
  provider?: 'openai' | 'gemini'
): Promise<EssayFeedback> {
  // If no API key provided or using mock, return mock feedback
  if (!apiKey || !provider) {
    console.log('[v0] Using mock feedback (no API key configured)');
    return MOCK_FEEDBACK;
  }

  try {
    const userPrompt = `Please analyze this ${academicLevel} level ${essayType} essay:\n\n${essay}`;

    if (provider === 'openai') {
      const { text } = await generateText({
        model: openai('gpt-4-turbo'),
        system: SYSTEM_PROMPT,
        prompt: userPrompt,
        apiKey: apiKey,
      });

      const feedback = JSON.parse(text);
      return feedback as EssayFeedback;
    } else if (provider === 'gemini') {
      // For Gemini, we'll use the fetch API directly since @ai-sdk/google is not available
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' + apiKey, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: `${SYSTEM_PROMPT}\n\n${userPrompt}`,
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          },
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('[v0] Gemini API error:', data);
        return MOCK_FEEDBACK;
      }

      const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!responseText) {
        return MOCK_FEEDBACK;
      }

      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        return MOCK_FEEDBACK;
      }

      const feedback = JSON.parse(jsonMatch[0]);
      return feedback as EssayFeedback;
    }

    return MOCK_FEEDBACK;
  } catch (error) {
    console.error('[v0] Error analyzing essay:', error);
    // Fallback to mock feedback on any error
    return MOCK_FEEDBACK;
  }
}
