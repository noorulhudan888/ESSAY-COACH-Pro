'use client';

import { useState, useEffect } from 'react';
import { Dashboard } from '@/components/dashboard';
import { EssayEditor } from '@/components/essay-editor';
import { FeedbackPanel } from '@/components/feedback-panel';
import { CitationGenerator } from '@/components/citation-generator';
import { OutlineBuilder } from '@/components/outline-builder';
import { Settings } from '@/components/settings';
import { Essay, getEssays, saveEssay, getApiKey, getApiProvider } from '@/lib/storage';
import { analyzeEssay } from '@/lib/ai-service';
import { BarChart3, PenTool, Settings as SettingsIcon, BookOpen, Lightbulb } from 'lucide-react';

type Tab = 'dashboard' | 'editor' | 'feedback' | 'citations' | 'outline';

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [essays, setEssays] = useState<Essay[]>([]);
  const [currentEssay, setCurrentEssay] = useState<Essay | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isHydrated, setIsHydrated] = useState(false);

  // Load essays from storage on mount
  useEffect(() => {
    const stored = getEssays();
    setEssays(stored);
    setIsHydrated(true);
  }, []);

  const handleAnalyzeClick = () => {
    setActiveTab('editor');
  };

  const handleAnalyzeEssay = async (text: string, level: string, type: string) => {
    setIsLoading(true);
    try {
      const essayId = `essay_${Date.now()}`;
      const apiKey = getApiKey();
      const provider = getApiProvider();

      // Analyze the essay
      const feedback = await analyzeEssay(text, level, type, apiKey, provider);

      // Create the essay object
      const essay: Essay = {
        id: essayId,
        title: `${type.charAt(0).toUpperCase() + type.slice(1)} Essay - ${new Date().toLocaleDateString()}`,
        content: text,
        academicLevel: level as 'high-school' | 'undergrad' | 'postgrad',
        essayType: type as 'argumentative' | 'descriptive' | 'narrative',
        createdAt: new Date().toISOString(),
        feedback,
      };

      // Save and update state
      saveEssay(essay);
      setCurrentEssay(essay);
      setEssays((prev) => [essay, ...prev]);
      setActiveTab('feedback');
    } catch (error) {
      console.error('[v0] Error analyzing essay:', error);
      alert('Failed to analyze essay. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectEssay = (essay: Essay) => {
    setCurrentEssay(essay);
    setActiveTab('feedback');
  };

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block">
            <div className="w-12 h-12 border-4 border-muted border-t-primary rounded-full animate-spin"></div>
          </div>
          <p className="text-foreground font-medium mt-4">Loading Essay Coach Pro...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                <PenTool className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Essay Coach Pro</h1>
                <p className="text-xs text-muted-foreground">AI-Powered Essay Analysis</p>
              </div>
            </div>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 hover:bg-background rounded-lg transition-colors text-muted-foreground hover:text-foreground"
              aria-label="Open settings"
            >
              <SettingsIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Tabs Navigation */}
      <div className="border-b border-border bg-card sticky top-[73px] z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1 overflow-x-auto">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-3 font-medium text-sm whitespace-nowrap transition-colors border-b-2 ${
                activeTab === 'dashboard'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Dashboard
              </div>
            </button>
            <button
              onClick={() => setActiveTab('editor')}
              className={`px-4 py-3 font-medium text-sm whitespace-nowrap transition-colors border-b-2 ${
                activeTab === 'editor'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className="flex items-center gap-2">
                <PenTool className="w-4 h-4" />
                Editor
              </div>
            </button>
            {currentEssay && (
              <button
                onClick={() => setActiveTab('feedback')}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap transition-colors border-b-2 ${
                  activeTab === 'feedback'
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Feedback
                </div>
              </button>
            )}
            <button
              onClick={() => setActiveTab('outline')}
              className={`px-4 py-3 font-medium text-sm whitespace-nowrap transition-colors border-b-2 ${
                activeTab === 'outline'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4" />
                Outline
              </div>
            </button>
            <button
              onClick={() => setActiveTab('citations')}
              className={`px-4 py-3 font-medium text-sm whitespace-nowrap transition-colors border-b-2 ${
                activeTab === 'citations'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                Citations
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <Dashboard essays={essays} onAnalyzeClick={handleAnalyzeClick} onSelectEssay={handleSelectEssay} />
        )}

        {activeTab === 'editor' && <EssayEditor onAnalyze={handleAnalyzeEssay} isLoading={isLoading} />}

        {activeTab === 'feedback' && currentEssay?.feedback && (
          <FeedbackPanel feedback={currentEssay.feedback} />
        )}

        {activeTab === 'outline' && <OutlineBuilder />}

        {activeTab === 'citations' && <CitationGenerator />}
      </main>

      {/* Settings Modal */}
      {showSettings && <Settings onClose={() => setShowSettings(false)} />}

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-auto">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-sm text-muted-foreground">
          <p>Essay Coach Pro © 2024 • Powered by AI</p>
        </div>
      </footer>
    </div>
  );
}
