'use client';

import { Essay } from '@/lib/storage';
import { BarChart3, TrendingUp, PenTool, Clock } from 'lucide-react';

interface DashboardProps {
  essays: Essay[];
  onAnalyzeClick: () => void;
  onSelectEssay: (essay: Essay) => void;
}

export function Dashboard({ essays, onAnalyzeClick, onSelectEssay }: DashboardProps) {
  const totalEssays = essays.length;
  const essaysWithFeedback = essays.filter((e) => e.feedback).length;
  const averageScore = essays.length > 0
    ? Math.round(essays.reduce((sum, e) => sum + (e.feedback?.score || 0), 0) / essays.length)
    : 0;

  const recentEssays = essays.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Track your essay progress and get instant feedback</p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Essays */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground font-medium">Total Essays</p>
              <p className="text-3xl font-bold text-foreground mt-2">{totalEssays}</p>
            </div>
            <div className="bg-primary/10 p-3 rounded-lg">
              <PenTool className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        {/* Analyzed Essays */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground font-medium">Analyzed</p>
              <p className="text-3xl font-bold text-foreground mt-2">{essaysWithFeedback}</p>
            </div>
            <div className="bg-accent/10 p-3 rounded-lg">
              <BarChart3 className="w-6 h-6 text-accent" />
            </div>
          </div>
        </div>

        {/* Average Score */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground font-medium">Average Score</p>
              <p className="text-3xl font-bold text-foreground mt-2">{averageScore}</p>
            </div>
            <div className="bg-secondary/10 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-secondary-foreground" />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={onAnalyzeClick}
          className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg p-6 font-semibold transition-all active:scale-95 flex flex-col items-center justify-center gap-2 min-h-[120px]"
        >
          <PenTool className="w-6 h-6" />
          <span className="text-sm">Analyze New Essay</span>
        </button>
      </div>

      {/* Recent Essays */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h2 className="text-xl font-bold text-foreground mb-4">Recent Essays</h2>
        {recentEssays.length === 0 ? (
          <div className="text-center py-8">
            <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
            <p className="text-muted-foreground">No essays yet. Start by analyzing your first essay!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {recentEssays.map((essay) => (
              <button
                key={essay.id}
                onClick={() => onSelectEssay(essay)}
                className="w-full text-left p-4 bg-background/50 hover:bg-background border border-border rounded-lg transition-colors group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors truncate">
                      {essay.title || 'Untitled Essay'}
                    </h3>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                        {essay.academicLevel.replace('-', ' ')}
                      </span>
                      <span className="text-xs bg-accent/10 text-accent px-2 py-1 rounded">
                        {essay.essayType}
                      </span>
                      {essay.feedback && (
                        <span className="text-xs bg-secondary/10 text-secondary-foreground px-2 py-1 rounded font-semibold">
                          {essay.feedback.grade}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-right ml-4 shrink-0">
                    <p className="text-xs text-muted-foreground">
                      {new Date(essay.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
