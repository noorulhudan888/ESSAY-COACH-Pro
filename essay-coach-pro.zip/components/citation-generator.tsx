'use client';

import { useState } from 'react';
import { Copy, Check } from 'lucide-react';

type CitationStyle = 'apa' | 'mla' | 'chicago';

interface Citation {
  author: string;
  title: string;
  publisher: string;
  year: string;
  url?: string;
  accessDate?: string;
}

export function CitationGenerator() {
  const [style, setStyle] = useState<CitationStyle>('apa');
  const [citation, setCitation] = useState<Citation>({
    author: '',
    title: '',
    publisher: '',
    year: '',
    url: '',
    accessDate: '',
  });
  const [generatedCitation, setGeneratedCitation] = useState('');
  const [copied, setCopied] = useState(false);

  const formatAPACitation = (): string => {
    if (!citation.author || !citation.title || !citation.year) {
      return 'Please fill in all required fields.';
    }
    let result = `${citation.author} (${citation.year}). ${citation.title}.`;
    if (citation.publisher) {
      result += ` ${citation.publisher}.`;
    }
    if (citation.url) {
      result += ` Retrieved from ${citation.url}`;
      if (citation.accessDate) {
        result += ` on ${citation.accessDate}`;
      }
    }
    return result;
  };

  const formatMLACitation = (): string => {
    if (!citation.author || !citation.title || !citation.year) {
      return 'Please fill in all required fields.';
    }
    let result = `${citation.author}. "${citation.title}." ${citation.publisher}, ${citation.year}.`;
    if (citation.url) {
      result += ` Web. ${citation.url}`;
      if (citation.accessDate) {
        result += ` Accessed ${citation.accessDate}.`;
      }
    }
    return result;
  };

  const formatChicagoCitation = (): string => {
    if (!citation.author || !citation.title || !citation.year) {
      return 'Please fill in all required fields.';
    }
    let result = `${citation.author}. ${citation.title}. ${citation.publisher}, ${citation.year}.`;
    if (citation.url) {
      result += ` Accessed ${citation.accessDate || 'today'} at ${citation.url}.`;
    }
    return result;
  };

  const generateCitation = () => {
    let formatted = '';
    switch (style) {
      case 'apa':
        formatted = formatAPACitation();
        break;
      case 'mla':
        formatted = formatMLACitation();
        break;
      case 'chicago':
        formatted = formatChicagoCitation();
        break;
    }
    setGeneratedCitation(formatted);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCitation).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">Citation Generator</h2>
          <p className="text-muted-foreground">Generate perfectly formatted academic citations in seconds.</p>
        </div>

        {/* Style Selection */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-3">Citation Style</label>
          <div className="flex gap-3 flex-wrap">
            {(['apa', 'mla', 'chicago'] as CitationStyle[]).map((s) => (
              <button
                key={s}
                onClick={() => setStyle(s)}
                className={`px-6 py-3 rounded-lg font-medium transition-all ${
                  style === s
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-secondary text-secondary-foreground hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                {s.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Input Form */}
        <div className="space-y-4 bg-card p-6 rounded-xl border border-border">
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Author <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={citation.author}
              onChange={(e) => setCitation({ ...citation, author: e.target.value })}
              placeholder="e.g., Smith, John"
              className="w-full px-4 py-2 border border-input rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={citation.title}
              onChange={(e) => setCitation({ ...citation, title: e.target.value })}
              placeholder="e.g., The Impact of Technology on Education"
              className="w-full px-4 py-2 border border-input rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">Publisher</label>
            <input
              type="text"
              value={citation.publisher}
              onChange={(e) => setCitation({ ...citation, publisher: e.target.value })}
              placeholder="e.g., Oxford University Press"
              className="w-full px-4 py-2 border border-input rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Year <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                value={citation.year}
                onChange={(e) => setCitation({ ...citation, year: e.target.value })}
                placeholder="e.g., 2024"
                className="w-full px-4 py-2 border border-input rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Access Date</label>
              <input
                type="date"
                value={citation.accessDate}
                onChange={(e) => setCitation({ ...citation, accessDate: e.target.value })}
                className="w-full px-4 py-2 border border-input rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">URL (optional)</label>
            <input
              type="url"
              value={citation.url}
              onChange={(e) => setCitation({ ...citation, url: e.target.value })}
              placeholder="e.g., https://example.com"
              className="w-full px-4 py-2 border border-input rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={generateCitation}
          className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity shadow-lg"
        >
          Generate Citation
        </button>

        {/* Generated Citation Display */}
        {generatedCitation && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div>
              <p className="text-sm font-semibold text-foreground mb-3">Your Citation ({style.toUpperCase()}):</p>
              <div className="bg-background p-4 rounded-lg border border-input">
                <p className="text-foreground leading-relaxed break-words">{generatedCitation}</p>
              </div>
            </div>
            <button
              onClick={copyToClipboard}
              className="w-full flex items-center justify-center gap-2 bg-accent text-accent-foreground py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
            >
              {copied ? (
                <>
                  <Check className="w-5 h-5" />
                  Copied to Clipboard!
                </>
              ) : (
                <>
                  <Copy className="w-5 h-5" />
                  Copy to Clipboard
                </>
              )}
            </button>
          </div>
        )}

        {/* Info Box */}
        <div className="bg-secondary/30 border border-secondary p-4 rounded-lg">
          <p className="text-sm text-foreground">
            <strong>Pro Tip:</strong> Always verify your citations match your institution&apos;s requirements, as citation formats can have slight variations.
          </p>
        </div>
      </div>
    </div>
  );
}
