'use client';

import { useState } from 'react';
import { getApiKey, getApiProvider, saveApiKey, clearApiKey } from '@/lib/storage';
import { Settings as SettingsIcon, Eye, EyeOff, Trash2, Check, X } from 'lucide-react';

interface SettingsProps {
  onClose: () => void;
}

export function Settings({ onClose }: SettingsProps) {
  const [provider, setProvider] = useState<'openai' | 'gemini' | ''>((getApiProvider() as any) || '');
  const [apiKey, setApiKey] = useState(getApiKey());
  const [showKey, setShowKey] = useState(false);
  const [saved, setSaved] = useState(false);
  const [displayedKey, setDisplayedKey] = useState('');

  // Obfuscate the key for display
  const obfuscateKey = (key: string) => {
    if (!key) return '';
    if (key.length <= 8) return '*'.repeat(key.length);
    return key.substring(0, 4) + '*'.repeat(Math.max(4, key.length - 8)) + key.slice(-4);
  };

  const handleSave = () => {
    if (provider && apiKey) {
      saveApiKey(apiKey, provider);
      setSaved(true);
      setDisplayedKey(obfuscateKey(apiKey));
      setApiKey('');
      setTimeout(() => setSaved(false), 3000);
    }
  };

  const handleClear = () => {
    if (confirm('Are you sure you want to remove your API key?')) {
      clearApiKey();
      setProvider('');
      setApiKey('');
      setDisplayedKey('');
      setSaved(false);
    }
  };

  const hasApiKey = displayedKey || getApiKey();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border sticky top-0 bg-card">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-lg">
              <SettingsIcon className="w-5 h-5 text-primary" />
            </div>
            <h2 className="text-xl font-bold text-foreground">Settings</h2>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Close settings"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* AI Provider Selection */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">AI Provider</h3>
            <div className="space-y-3">
              <label className="flex items-center p-4 border border-border rounded-lg cursor-pointer hover:bg-background/50 transition-colors">
                <input
                  type="radio"
                  name="provider"
                  value="openai"
                  checked={provider === 'openai'}
                  onChange={(e) => setProvider('openai' as any)}
                  className="w-4 h-4 accent-primary"
                />
                <div className="ml-3">
                  <p className="font-medium text-foreground">OpenAI (GPT-4)</p>
                  <p className="text-xs text-muted-foreground mt-1">Advanced model with superior analysis</p>
                </div>
              </label>

              <label className="flex items-center p-4 border border-border rounded-lg cursor-pointer hover:bg-background/50 transition-colors">
                <input
                  type="radio"
                  name="provider"
                  value="gemini"
                  checked={provider === 'gemini'}
                  onChange={(e) => setProvider('gemini' as any)}
                  className="w-4 h-4 accent-primary"
                />
                <div className="ml-3">
                  <p className="font-medium text-foreground">Google Gemini</p>
                  <p className="text-xs text-muted-foreground mt-1">Fast, capable model with free tier</p>
                </div>
              </label>
            </div>
          </div>

          {/* API Key Input */}
          {provider && (
            <div>
              <label htmlFor="api-key" className="block text-sm font-medium text-foreground mb-2">
                API Key
              </label>
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <input
                    id="api-key"
                    type={showKey ? 'text' : 'password'}
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder={hasApiKey ? displayedKey : 'Paste your API key here...'}
                    className="w-full px-4 py-2 rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  <button
                    onClick={() => setShowKey(!showKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {provider === 'openai'
                  ? 'Get your OpenAI API key from https://platform.openai.com/api-keys'
                  : 'Get your Gemini API key from https://makersuite.google.com/app/apikey'}
              </p>
            </div>
          )}

          {/* Status Messages */}
          {saved && (
            <div className="bg-green-50 border border-green-200 text-green-900 p-3 rounded-lg flex items-center gap-2 dark:bg-green-950 dark:border-green-800 dark:text-green-100">
              <Check className="w-5 h-5 flex-shrink-0" />
              <p className="text-sm font-medium">API key saved successfully!</p>
            </div>
          )}

          {hasApiKey && !apiKey && (
            <div className="bg-blue-50 border border-blue-200 text-blue-900 p-3 rounded-lg dark:bg-blue-950 dark:border-blue-800 dark:text-blue-100">
              <p className="text-sm font-medium">✓ API key is configured</p>
              <p className="text-xs mt-1 opacity-80">Your essays will be analyzed with real AI feedback</p>
            </div>
          )}

          {!hasApiKey && !provider && (
            <div className="bg-yellow-50 border border-yellow-200 text-yellow-900 p-3 rounded-lg dark:bg-yellow-950 dark:border-yellow-800 dark:text-yellow-100">
              <p className="text-sm font-medium">No API key configured</p>
              <p className="text-xs mt-1 opacity-80">Essays will use mock feedback until you add an API key</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-border p-6 space-y-3">
          {provider && (
            <button
              onClick={handleSave}
              disabled={!apiKey}
              className="w-full bg-primary hover:bg-primary/90 disabled:bg-muted disabled:cursor-not-allowed text-primary-foreground font-semibold py-2 px-4 rounded-lg transition-all"
            >
              Save API Key
            </button>
          )}

          {hasApiKey && (
            <button
              onClick={handleClear}
              className="w-full flex items-center justify-center gap-2 bg-destructive/10 hover:bg-destructive/20 text-destructive border border-destructive/30 font-semibold py-2 px-4 rounded-lg transition-all"
            >
              <Trash2 className="w-4 h-4" />
              Remove API Key
            </button>
          )}

          <button
            onClick={onClose}
            className="w-full bg-background hover:bg-muted border border-border text-foreground font-semibold py-2 px-4 rounded-lg transition-all"
          >
            Close
          </button>
        </div>

        {/* Info Section */}
        <div className="border-t border-border p-6 bg-background/50 space-y-3">
          <p className="text-xs text-muted-foreground font-medium">How it works:</p>
          <ul className="text-xs text-muted-foreground space-y-2">
            <li className="flex gap-2">
              <span className="text-primary font-bold">1.</span>
              <span>Choose your preferred AI provider above</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary font-bold">2.</span>
              <span>Paste your API key when you have one</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary font-bold">3.</span>
              <span>Close settings and analyze essays normally</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
