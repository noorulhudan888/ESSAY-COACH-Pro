'use client';

import { useState } from 'react';
import { Loader2, Zap } from 'lucide-react';

interface EssayEditorProps {
  onAnalyze: (text: string, level: string, type: string) => Promise<void>;
  isLoading: boolean;
}

export function EssayEditor({ onAnalyze, isLoading }: EssayEditorProps) {
  const [essayText, setEssayText] = useState('');
  const [academicLevel, setAcademicLevel] = useState('undergrad');
  const [essayType, setEssayType] = useState('argumentative');

  const handleAnalyze = async () => {
    if (essayText.trim().length < 50) {
      alert('Please write at least 50 characters for analysis.');
      return;
    }
    await onAnalyze(essayText, academicLevel, essayType);
  };

  const wordCount = essayText.trim().split(/\s+/).filter(Boolean).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-foreground">Essay Editor</h1>
        <p className="text-muted-foreground">Paste or type your essay below to get AI-powered feedback</p>
      </div>

      {/* Options Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Academic Level */}
        <div>
          <label htmlFor="academic-level" className="block text-sm font-medium text-foreground mb-2">
            Academic Level
          </label>
          <select
            id="academic-level"
            value={academicLevel}
            onChange={(e) => setAcademicLevel(e.target.value)}
            disabled={isLoading}
            className="w-full px-4 py-2 rounded-lg border border-input bg-card text-foreground disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="high-school">High School</option>
            <option value="undergrad">Undergraduate</option>
            <option value="postgrad">Postgraduate</option>
          </select>
        </div>

        {/* Essay Type */}
        <div>
          <label htmlFor="essay-type" className="block text-sm font-medium text-foreground mb-2">
            Essay Type
          </label>
          <select
            id="essay-type"
            value={essayType}
            onChange={(e) => setEssayType(e.target.value)}
            disabled={isLoading}
            className="w-full px-4 py-2 rounded-lg border border-input bg-card text-foreground disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="argumentative">Argumentative</option>
            <option value="descriptive">Descriptive</option>
            <option value="narrative">Narrative</option>
          </select>
        </div>
      </div>

      {/* Essay Text Area */}
      <div>
        <label htmlFor="essay-text" className="block text-sm font-medium text-foreground mb-2">
          Your Essay
        </label>
        <textarea
          id="essay-text"
          value={essayText}
          onChange={(e) => setEssayText(e.target.value)}
          disabled={isLoading}
          placeholder="Paste or type your essay here. The more content you provide, the more detailed the feedback will be..."
          className="w-full h-96 px-4 py-3 rounded-lg border border-input bg-card text-foreground placeholder:text-muted-foreground disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-primary resize-none"
        />
        <div className="flex justify-end mt-2">
          <p className="text-xs text-muted-foreground">
            {wordCount} word{wordCount !== 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Analyze Button */}
      <button
        onClick={handleAnalyze}
        disabled={isLoading || essayText.trim().length === 0}
        className="w-full bg-primary hover:bg-primary/90 disabled:bg-muted disabled:cursor-not-allowed text-primary-foreground font-semibold py-3 px-6 rounded-lg transition-all active:scale-95 flex items-center justify-center gap-2"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Analyzing your essay...</span>
          </>
        ) : (
          <>
            <Zap className="w-5 h-5" />
            <span>Analyze Essay</span>
          </>
        )}
      </button>

      {/* Info Box */}
      <div className="bg-accent/10 border border-accent rounded-lg p-4">
        <p className="text-sm text-foreground">
          <span className="font-semibold">💡 Pro Tip:</span> For the best feedback, write essays with clear structure including introduction, body paragraphs, and conclusion.
        </p>
      </div>
    </div>
  );
}
