'use client';

import { useState } from 'react';
import { Copy, Check, Loader2 } from 'lucide-react';
import { generateOutline } from '@/lib/outline-service';
import { getApiKey, getApiProvider } from '@/lib/storage';

interface OutlineSection {
  heading: string;
  points: string[];
}

export function OutlineBuilder() {
  const [topic, setTopic] = useState('');
  const [wordCount, setWordCount] = useState('1500');
  const [outline, setOutline] = useState<OutlineSection[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const handleGenerateOutline = async () => {
    if (!topic.trim()) {
      setError('Please enter a topic or prompt.');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      const apiKey = getApiKey();
      const provider = getApiProvider();
      const generatedOutline = await generateOutline(topic, parseInt(wordCount), apiKey, provider);
      setOutline(generatedOutline);
    } catch (err) {
      setError('Failed to generate outline. Please try again.');
      console.error('[v0] Outline generation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const copyOutlineToClipboard = () => {
    const text = outline
      .map((section) => `${section.heading}\n${section.points.map((p) => `• ${p}`).join('\n')}`)
      .join('\n\n');

    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const outlineText = outline
    .map((section) => `${section.heading}\n${section.points.map((p) => `• ${p}`).join('\n')}`)
    .join('\n\n');

  return (
    <div className="max-w-3xl mx-auto">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">AI Outline Builder</h2>
          <p className="text-muted-foreground">
            Let AI help you structure your essay with a comprehensive, paragraph-by-paragraph outline.
          </p>
        </div>

        {/* Input Section */}
        <div className="bg-card border border-border rounded-xl p-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Essay Topic or Prompt <span className="text-red-500">*</span>
            </label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Discuss the impact of artificial intelligence on modern education or Argue why remote work is beneficial for productivity"
              className="w-full px-4 py-3 border border-input rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              rows={4}
            />
            <p className="text-xs text-muted-foreground mt-2">
              Be specific about your topic or research question for better results.
            </p>
          </div>

          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">Target Word Count</label>
            <div className="flex gap-3">
              {[500, 1000, 1500, 2500, 5000].map((count) => (
                <button
                  key={count}
                  onClick={() => setWordCount(count.toString())}
                  className={`px-4 py-2 rounded-lg font-medium text-sm transition-all ${
                    wordCount === count.toString()
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground hover:bg-accent hover:text-accent-foreground'
                  }`}
                >
                  {count.toLocaleString()}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200 px-4 py-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        {/* Generate Button */}
        <button
          onClick={handleGenerateOutline}
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Generating Outline...
            </>
          ) : (
            'Generate Outline'
          )}
        </button>

        {/* Generated Outline Display */}
        {outline.length > 0 && (
          <div className="space-y-4">
            <div className="bg-card border border-border rounded-xl p-6 space-y-6">
              <div>
                <h3 className="text-lg font-bold text-foreground mb-4">Your Essay Outline</h3>
                <div className="space-y-6">
                  {outline.map((section, sectionIdx) => (
                    <div key={sectionIdx}>
                      <div className="flex items-start gap-3 mb-3">
                        <div className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-semibold text-sm">
                          {sectionIdx + 1}
                        </div>
                        <h4 className="text-base font-semibold text-foreground pt-1">{section.heading}</h4>
                      </div>
                      <ul className="space-y-2 ml-11">
                        {section.points.map((point, pointIdx) => (
                          <li key={pointIdx} className="flex gap-3 text-sm text-foreground">
                            <span className="text-accent font-semibold flex-shrink-0">•</span>
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Copy Button */}
            <button
              onClick={copyOutlineToClipboard}
              className="w-full flex items-center justify-center gap-2 bg-accent text-accent-foreground py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
            >
              {copied ? (
                <>
                  <Check className="w-5 h-5" />
                  Copied to Clipboard!
                </>
              ) : (
                <>
                  <Copy className="w-5 h-5" />
                  Copy Full Outline
                </>
              )}
            </button>

            {/* Tips */}
            <div className="bg-secondary/30 border border-secondary p-4 rounded-lg space-y-2">
              <p className="text-sm font-semibold text-foreground">Tips for using this outline:</p>
              <ul className="space-y-1 text-sm text-foreground">
                <li>✓ Use this as a starting point and customize it for your specific needs</li>
                <li>✓ Expand each section based on your research and arguments</li>
                <li>✓ Reorder sections if needed to improve logical flow</li>
                <li>✓ Add evidence, quotes, and examples to support each point</li>
              </ul>
            </div>
          </div>
        )}

        {/* Features Info */}
        {outline.length === 0 && (
          <div className="bg-secondary/20 border border-secondary p-6 rounded-xl space-y-4">
            <h3 className="font-semibold text-foreground">How it works:</h3>
            <ul className="space-y-3 text-sm text-foreground">
              <li className="flex gap-3">
                <span className="text-accent font-bold">1.</span>
                <span>Enter your essay topic or research question</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent font-bold">2.</span>
                <span>Select your target word count</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent font-bold">3.</span>
                <span>AI generates a complete paragraph-by-paragraph outline</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent font-bold">4.</span>
                <span>Copy the outline and start writing with confidence</span>
              </li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
