'use client';

import { useState } from 'react';
import { EssayFeedback } from '@/lib/storage';
import { ChevronDown, ChevronUp, CheckCircle2, AlertCircle, Lightbulb, BarChart3 } from 'lucide-react';

interface FeedbackPanelProps {
  feedback: EssayFeedback;
}

export function FeedbackPanel({ feedback }: FeedbackPanelProps) {
  const [expandedSections, setExpandedSections] = useState<{
    [key: string]: boolean;
  }>({
    structure: true,
    grammar: true,
    actionable: true,
  });

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'bg-green-50 border-green-200 text-green-900 dark:bg-green-950 dark:border-green-800';
    if (grade.startsWith('B')) return 'bg-blue-50 border-blue-200 text-blue-900 dark:bg-blue-950 dark:border-blue-800';
    if (grade.startsWith('C')) return 'bg-yellow-50 border-yellow-200 text-yellow-900 dark:bg-yellow-950 dark:border-yellow-800';
    return 'bg-red-50 border-red-200 text-red-900 dark:bg-red-950 dark:border-red-800';
  };

  const gradeColorClass = getGradeColor(feedback.grade);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-foreground">Feedback Report</h1>
        <p className="text-muted-foreground">Detailed analysis of your essay with actionable improvements</p>
      </div>

      {/* Grade Card */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className={`border-2 rounded-lg p-8 ${gradeColorClass}`}>
          <p className="text-sm font-medium opacity-75">Overall Grade</p>
          <p className="text-5xl font-bold mt-2">{feedback.grade}</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-8 flex flex-col justify-center">
          <p className="text-sm font-medium text-muted-foreground">Score Out of 100</p>
          <p className="text-5xl font-bold text-primary mt-2">{feedback.score}</p>
          <div className="w-full bg-input rounded-full h-2 mt-4">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-500"
              style={{ width: `${feedback.score}%` }}
            />
          </div>
        </div>
      </div>

      {/* Structure & Flow Section */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <button
          onClick={() => toggleSection('structure')}
          className="w-full p-6 flex items-center justify-between hover:bg-background/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-lg">
              <BarChart3 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Structure & Flow</h3>
              <p className="text-xs text-muted-foreground">Essay organization and coherence</p>
            </div>
          </div>
          {expandedSections.structure ? (
            <ChevronUp className="w-5 h-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          )}
        </button>

        {expandedSections.structure && (
          <div className="px-6 pb-6 space-y-4 border-t border-border">
            <div className="bg-background/50 p-4 rounded-lg">
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-1" />
                <div>
                  <p className="font-medium text-foreground text-sm">Introduction</p>
                  <p className="text-sm text-muted-foreground mt-1">{feedback.structure.introduction}</p>
                </div>
              </div>
            </div>

            <div className="bg-background/50 p-4 rounded-lg">
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-1" />
                <div>
                  <p className="font-medium text-foreground text-sm">Thesis Statement</p>
                  <p className="text-sm text-muted-foreground mt-1">{feedback.structure.thesis}</p>
                </div>
              </div>
            </div>

            <div className="bg-background/50 p-4 rounded-lg">
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-1" />
                <div>
                  <p className="font-medium text-foreground text-sm">Body Paragraphs</p>
                  <p className="text-sm text-muted-foreground mt-1">{feedback.structure.bodyParagraphs}</p>
                </div>
              </div>
            </div>

            <div className="bg-background/50 p-4 rounded-lg">
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-1" />
                <div>
                  <p className="font-medium text-foreground text-sm">Conclusion</p>
                  <p className="text-sm text-muted-foreground mt-1">{feedback.structure.conclusion}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Grammar & Tone Section */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <button
          onClick={() => toggleSection('grammar')}
          className="w-full p-6 flex items-center justify-between hover:bg-background/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="bg-accent/10 p-2 rounded-lg">
              <AlertCircle className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Grammar & Tone</h3>
              <p className="text-xs text-muted-foreground">Major improvements needed</p>
            </div>
          </div>
          {expandedSections.grammar ? (
            <ChevronUp className="w-5 h-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          )}
        </button>

        {expandedSections.grammar && (
          <div className="px-6 pb-6 space-y-3 border-t border-border">
            {feedback.grammar.map((item, index) => (
              <div key={index} className="flex gap-3 p-3 bg-background/50 rounded-lg">
                <div className="flex-shrink-0 w-6 h-6 bg-accent/20 rounded-full flex items-center justify-center">
                  <span className="text-xs font-semibold text-accent">{index + 1}</span>
                </div>
                <p className="text-sm text-muted-foreground">{item}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Actionable Steps Section */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <button
          onClick={() => toggleSection('actionable')}
          className="w-full p-6 flex items-center justify-between hover:bg-background/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="bg-secondary/10 p-2 rounded-lg">
              <Lightbulb className="w-5 h-5 text-secondary-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Actionable Steps</h3>
              <p className="text-xs text-muted-foreground">Exercises to improve this essay</p>
            </div>
          </div>
          {expandedSections.actionable ? (
            <ChevronUp className="w-5 h-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          )}
        </button>

        {expandedSections.actionable && (
          <div className="px-6 pb-6 space-y-3 border-t border-border">
            {feedback.actionableSteps.map((step, index) => (
              <div
                key={index}
                className="p-4 bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/20 rounded-lg"
              >
                <p className="font-semibold text-foreground text-sm mb-2">
                  <span className="bg-primary text-primary-foreground px-2 py-1 rounded text-xs mr-2 inline-block">
                    {index + 1}
                  </span>
                </p>
                <p className="text-sm text-muted-foreground">{step}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Note */}
      <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
        <p className="text-sm text-foreground">
          <span className="font-semibold">📝 Note:</span> Use this feedback to revise and improve your next draft. Focus on implementing the actionable steps for maximum impact.
        </p>
      </div>
    </div>
  );
}
