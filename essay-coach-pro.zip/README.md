# Essay Coach Pro - AI-Powered Essay Analysis Platform

A comprehensive, production-ready React web application that helps students improve their writing through AI-powered analysis, citation generation, and intelligent outline building. Built with Next.js 16, React 19, TypeScript, and Tailwind CSS.

## 🎯 Core Features

### 1. Dashboard
- **Progress Metrics**: View total essays, number analyzed, and average score
- **Recent Essays**: Quick access to your essay history with grades and metadata
- **One-Click Analysis**: Start analyzing a new essay with a single click
- **Real-time Stats**: Dynamically updates when new essays are analyzed

### 2. Essay Editor with AI Analysis
- **Large Text Area**: Comfortable writing and pasting experience with live word count
- **Academic Level Selection**: Choose from High School, Undergraduate, or Postgraduate
- **Essay Type Selection**: Select Argumentative, Descriptive, or Narrative essays
- **AI-Powered Analysis**: Submit essays for real-time feedback using GPT-4 or Gemini
- **Loading Indicator**: Visual feedback during analysis
- **Mock Fallback**: Works instantly without API key using realistic sample feedback

### 3. AI Feedback Panel
- **Overall Grade**: A-F grading system with color-coded display (A=green, B=blue, C=yellow, D/F=red)
- **Score Out of 100**: Visual progress bar showing numeric score
- **Structure & Flow**: 
  - Introduction critique
  - Thesis statement analysis
  - Body paragraphs evaluation
  - Conclusion assessment
- **Grammar & Tone**: 3 specific grammatical or stylistic improvements with explanations
- **Actionable Steps**: 3 concrete, detailed exercises the student can implement
- **Collapsible Sections**: Expand/collapse feedback sections for easy navigation

### 4. Citation Generator (NEW!)
- **Multiple Citation Formats**: 
  - APA style citations
  - MLA style citations
  - Chicago style citations
- **Form Inputs**: 
  - Author name (required)
  - Publication title (required)
  - Publisher
  - Publication year (required)
  - Access date (optional)
  - URL (optional)
- **Instant Generation**: Click to generate perfectly formatted citations
- **Copy to Clipboard**: One-click copy functionality with success feedback
- **Format Switching**: Instantly convert between citation styles

### 5. AI Outline Builder (NEW!)
- **Smart Topic Input**: Enter any essay topic or research question
- **Word Count Selection**: Choose from 500, 1000, 1500, 2500, or 5000 words
- **AI-Generated Outlines**: Produces paragraph-by-paragraph structure
- **Numbered Sections**: Clear organization with visual numbering
- **Actionable Points**: Each section includes specific points to cover
- **Copy Full Outline**: Export entire outline to clipboard
- **Best Practices Tips**: Guidance on using outlines effectively
- **Mock Support**: Works without API key for demonstration

### 6. Settings Panel
- **API Key Configuration**: Add OpenAI or Google Gemini API keys
- **Provider Selection**: Choose between GPT-4 (OpenAI) or Gemini (Google) models
- **Secure Storage**: API keys stored locally in localStorage with obfuscation
- **Mock Fallback**: Built-in mock feedback for testing without an API key
- **Key Visibility Toggle**: Hide/show API key with an eye icon
- **Clear & Reset**: Remove stored credentials anytime

## 🚀 Quick Start

### Installation

```bash
# Install dependencies
pnpm install

# Start the development server
pnpm dev

# Open in browser at http://localhost:3000
```

### Building for Production

```bash
pnpm build
pnpm start
```

### First Time Usage

1. **Dashboard**: See your writing progress and recent essays
2. **Editor**: Click "Analyze New Essay" to start writing
3. **Citations**: Generate academic citations in APA, MLA, or Chicago format
4. **Outline**: Input a topic to get AI-generated essay structure
5. **Settings**: (Optional) Add your API key for real AI analysis

## 📖 Usage Guide

### Analyzing Essays

1. Click **"Analyze New Essay"** button on Dashboard or go to **Editor** tab
2. **Paste or type** your essay in the text area
3. **Select** your Academic Level (High School, Undergrad, Postgrad)
4. **Select** your Essay Type (Argumentative, Descriptive, Narrative)
5. Click **"Submit for Analysis"**
6. View detailed feedback immediately in the **Feedback** tab

### Generating Citations

1. Navigate to the **Citations** tab
2. **Select** your citation format (APA, MLA, or Chicago)
3. **Fill in** the required fields:
   - Author name
   - Publication title
   - Year published
4. **(Optional)** Add publisher, URL, and access date
5. Click **"Generate Citation"**
6. Click **"Copy to Clipboard"** to use in your document

### Building Essay Outlines

1. Go to the **Outline** tab
2. **Enter** your essay topic or research question
3. **Select** your target word count (500 to 5000 words)
4. Click **"Generate Outline"**
5. Review the structured outline with:
   - Introduction section with hook and thesis points
   - Body paragraphs with topic sentences and support points
   - Conclusion with summary and closing strategies
6. Click **"Copy Full Outline"** to paste into a document

### Dashboard Features

1. **Track Progress**: See metrics for total essays, analyzed count, and average score
2. **View History**: Click any recent essay to view its feedback again
3. **Quick Access**: All essays stored locally and persisted across sessions

## 🔧 Configuration

### Adding an API Key

1. Click the **Settings** icon (⚙️) in the top-right corner
2. Select your preferred AI provider:
   - **OpenAI (GPT-4)**: Get your key from https://platform.openai.com/api-keys
   - **Google Gemini**: Get your key from https://ai.google.dev
3. Paste your API key into the input field
4. Select the provider from the dropdown
5. Click **"Save API Key"**
6. Your essays and outlines will now use real AI instead of mock data

### Using Without an API Key

The app comes with built-in mock feedback and outlines for testing and demonstration. Simply use all features without configuring an API key, and you'll receive example responses instantly. This is perfect for:
- Testing the interface
- Understanding how the tool works
- Using the Citation Generator (no API needed)
- Trying before committing to an API subscription

## 📱 Mobile Responsive

The app is fully optimized for mobile devices:
- ✅ Touch-friendly buttons (minimum 48px)
- ✅ Responsive grid layouts
- ✅ Stacked navigation on mobile
- ✅ Optimized text sizes for readability
- ✅ Smooth scrolling and interactions
- ✅ Tested on viewport sizes from 375px to 1920px+

## 🛠️ Tech Stack

- **Framework**: Next.js 16 with React 19 and App Router
- **Language**: TypeScript with strict mode
- **Styling**: Tailwind CSS v4 with oklch colors
- **UI Components**: shadcn/ui (button, card, input, etc.)
- **Icons**: Lucide React (24+ icons)
- **AI Integration**: 
  - Vercel AI SDK 7.0+ with generateText
  - OpenAI GPT-4 Turbo
  - Google Gemini Pro
- **Storage**: Browser localStorage (no backend required)
- **Bundler**: Turbopack (Next.js 16 default)

## 📋 AI System Prompts

### Essay Analysis Prompt
```
You are Essay Coach Pro, an elite academic writing coach. Analyze the user's essay based on their specified academic level and essay type. Provide a JSON response covering:
1. Overall Grade (A-F style) and an overall score out of 100.
2. Structure & Flow: Critiques of the introduction, thesis statement, body paragraphs, and conclusion.
3. Grammar & Tone: Pinpoint 3 major grammatical or stylistic improvements.
4. Actionable Steps: Give 3 explicit exercises or changes the student should make to improve this exact essay.

Respond with ONLY valid JSON in this exact structure:
{
  "grade": "A",
  "score": 92,
  "structure": {
    "introduction": "...",
    "thesis": "...",
    "bodyParagraphs": "...",
    "conclusion": "..."
  },
  "grammar": ["Issue 1", "Issue 2", "Issue 3"],
  "actionableSteps": ["Step 1", "Step 2", "Step 3"]
}
```

### Outline Generation Prompt
```
You are an expert academic writing coach specializing in essay structure and organization. Generate a comprehensive, well-organized essay outline based on the user's topic and target word count. Structure the outline with clear sections and bullet points.

Respond with ONLY valid JSON:
{
  "outline": [
    {
      "heading": "Introduction",
      "points": ["Hook statement", "Background", "Thesis"]
    },
    {
      "heading": "Body Paragraph 1",
      "points": ["Topic sentence", "Evidence", "Analysis"]
    }
  ]
}
```

## 💾 Data Storage

All essay data and API keys are stored locally in your browser's localStorage:
- **Essays**: Full text, metadata, feedback, and timestamps
- **API Configuration**: Provider type and obfuscated API key
- **No cloud sync**: Data persists only on the device where it's saved
- **Privacy**: All data remains on your device, never sent to external servers (except API calls)

## 🎨 Design System

### Colors
- **Primary**: Blue (`#6b7adb` light, `#a6baff` dark) - Main actions and branding
- **Accent**: Green (`#52c68a` light, `#a6d9b8` dark) - Positive feedback
- **Secondary**: Yellow (`#fbb040`) - Neutral highlights
- **Background**: Off-white to dark (`#faf8f6` to `#1a1a2e`)
- **Card**: White/dark surfaces with subtle borders

### Typography
- **Sans-serif**: System font stack for optimal readability
- **Font sizes**: Scaled from 12px to 32px with clear hierarchy
- **Line height**: 1.4-1.6 for comfortable reading

## 🔒 Privacy & Security

- ✅ **Client-side only**: No backend servers or databases
- ✅ **localStorage encryption**: Recommended to enable browser's built-in encryption
- ✅ **API keys**: Only sent to your chosen AI provider
- ✅ **No tracking**: No analytics or tracking pixels
- ✅ **Open source**: Audit the code whenever you want

## 🐛 Troubleshooting

### Essays Not Saving?
- Check that your browser allows localStorage
- Clear browser cache and try again
- Ensure you have enough storage space

### Analysis Not Working?
1. Verify your API key is correctly entered in Settings
2. Check that your API key has available credits/quota
3. Try the mock feedback first to ensure the app is working
4. Check your browser's console for error messages

### Missing UI Elements?
- Hard refresh your browser (Cmd+Shift+R on Mac, Ctrl+Shift+R on Windows)
- Clear browser cache
- Update your browser to the latest version

## 📚 Project Structure

```
/app
  /layout.tsx                # Root layout with metadata, theme, fonts
  /globals.css               # Tailwind v4 and theme setup with oklch colors
  /page.tsx                  # Main app component with 5-tab routing

/components
  /dashboard.tsx             # Dashboard: metrics, essay history, quick action
  /essay-editor.tsx          # Editor: textarea, level/type dropdowns, analyze button
  /feedback-panel.tsx        # Feedback: grade, score, structure, grammar, actions
  /citation-generator.tsx    # Citations: APA/MLA/Chicago format generator
  /outline-builder.tsx       # Outline: AI outline generation with topic & word count
  /settings.tsx              # Settings modal: API key configuration

/lib
  /storage.ts                # localStorage utilities for essays and API keys
  /ai-service.ts             # Essay analysis service with AI SDK
  /outline-service.ts        # Outline generation service with AI SDK
  /utils.ts                  # General utilities (cn function)

/public
  # Static assets (icons, fonts)
```

## 🚀 Deployment

### Deploy to Vercel

```bash
# One-click deployment
vercel
```

### Deploy to Other Platforms

The app is a standard Next.js app and can be deployed to:
- Vercel (recommended)
- Netlify
- Railway
- AWS
- Any Node.js hosting

## 📝 License

This project is provided as-is for educational and personal use.

## 🤝 Support

For issues, questions, or feedback, please refer to the Vercel documentation or open an issue in your deployment platform.

---

**Built with v0** - AI-powered React component generator
